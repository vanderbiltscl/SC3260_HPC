import sys
sys.path.append("..")
import ScheduleFlow

import numpy as np
import csv

import cProfile
import re

def generate_workload(file_day):
    job_list = []
    with open(file_day, newline='') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0]=="":
                continue
            job_list.append(ScheduleFlow.Application(
                int(row[2]), int(row[1]), int(row[3]), [2*int(row[3])]))
    return job_list

day = "2018-06-24"
total_nodes = 5936
job_list = generate_workload(
    "/home/anagainaru/work/scheduler_simulator/XSEDE/hpc_stats/XSEDE/%s.csv" %(day))


metrics = ["system utilization", "job response time", "job wait time"]
simulator = ScheduleFlow.Simulator(check_correctness=True)
sch = ScheduleFlow.BatchScheduler(ScheduleFlow.System(total_nodes))
                                  #total_queues=2)
simulator.create_scenario(sch, job_list=job_list, scenario_name="Batch_mwq")
cProfile.run('simulator.run(metrics=["system"])')


